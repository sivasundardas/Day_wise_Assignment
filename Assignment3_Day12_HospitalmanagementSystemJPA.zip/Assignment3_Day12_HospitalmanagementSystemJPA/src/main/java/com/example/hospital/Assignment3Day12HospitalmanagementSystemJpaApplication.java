package com.example.hospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment3Day12HospitalmanagementSystemJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment3Day12HospitalmanagementSystemJpaApplication.class, args);
	}

}
