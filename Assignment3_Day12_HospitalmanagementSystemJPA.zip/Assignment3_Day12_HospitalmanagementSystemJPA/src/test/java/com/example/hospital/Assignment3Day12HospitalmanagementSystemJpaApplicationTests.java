package com.example.hospital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment3Day12HospitalmanagementSystemJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
