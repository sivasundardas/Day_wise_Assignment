package com.example.springtest;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment1Day13ProductOrderManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment1Day13ProductOrderManagementSystemApplication.class, args);
	}
	
	 

}
