package com.example.springtest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springtest.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Long>{

}
