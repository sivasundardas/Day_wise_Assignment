package com.example.collegemanagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.collegemanagement.entity.Student;
import com.example.collegemanagement.repository.StudentRepository;

@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	private StudentRepository studentRepository;
	
	@PostMapping("/students")
    public Student addStudent(@RequestBody Student s) {
        return studentRepository.save(s);
    }
 
    @GetMapping("/students")
    public List<Student> getStudents() {
        return studentRepository.findAll();
    }
 
    @GetMapping("/students/{id}")
    public Optional<Student> getStudentById(@PathVariable long id) {
        return studentRepository.findById(id);
    }
 
    @PutMapping("/students/{id}")
    public Student updateStudent(@PathVariable long id, @RequestBody Student s) {
       // s.setId(id);
        return studentRepository.save(s);
    }
 
    @DeleteMapping("/students/{id}")
    public String deleteStudent(@PathVariable long id) {
        studentRepository.deleteById(id);
        return "Deleted Successfully";
    }
}
