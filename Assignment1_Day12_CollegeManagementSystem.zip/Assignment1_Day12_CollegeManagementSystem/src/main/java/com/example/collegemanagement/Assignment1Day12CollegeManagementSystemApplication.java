package com.example.collegemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment1Day12CollegeManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment1Day12CollegeManagementSystemApplication.class, args);
	}

}
