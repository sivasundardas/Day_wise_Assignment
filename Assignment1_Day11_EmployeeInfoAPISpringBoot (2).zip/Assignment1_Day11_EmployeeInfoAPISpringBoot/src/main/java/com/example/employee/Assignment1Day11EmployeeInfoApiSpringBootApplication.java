package com.example.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment1Day11EmployeeInfoApiSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment1Day11EmployeeInfoApiSpringBootApplication.class, args);
	}

}
