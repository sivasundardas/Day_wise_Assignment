package com.example.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment2Day11MonitoringAnInventorySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment2Day11MonitoringAnInventorySystemApplication.class, args);
	}

}
