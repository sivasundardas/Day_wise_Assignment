package com.example.hospital;

public class Patient {
    public void registerPatient() {
        System.out.println("Patient registered successfully.");
    }

    public void getPatientDetails() {
        System.out.println("Displaying patient details.");
    }
}
