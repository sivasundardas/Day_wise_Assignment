package com.example.hospital;

public class Billing {
    public void generateBill() {
        System.out.println("Bill generated.");
    }

    public void sendBill() {
        System.out.println("Bill sent to patient via email.");
    }
}
