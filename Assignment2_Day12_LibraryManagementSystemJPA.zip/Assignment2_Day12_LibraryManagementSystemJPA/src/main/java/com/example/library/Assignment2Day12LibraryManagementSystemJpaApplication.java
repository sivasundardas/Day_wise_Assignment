package com.example.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment2Day12LibraryManagementSystemJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment2Day12LibraryManagementSystemJpaApplication.class, args);
	}

}
