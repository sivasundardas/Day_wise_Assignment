package com.example.library.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.library.entity.Author;
import com.example.library.entity.Book;
import com.example.library.entity.Category;
import com.example.library.entity.Reader;
import com.example.library.repository.AuthorRepository;
import com.example.library.repository.BookRepository;
import com.example.library.repository.CategoryRepository;
import com.example.library.repository.ReaderRepository;

@RestController
@RequestMapping("/api")
public class LibraryController {

	@Autowired
	private AuthorRepository authorRepository;

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private ReaderRepository readerRepository;

	// Reader endpoints
	@PostMapping("/readers")
	public Reader addReader(@RequestBody Reader reader) {
		return readerRepository.save(reader);
	}

	@GetMapping("/readers")
	public List<Reader> getAllReaders() {
		return readerRepository.findAll();
	}

	@PutMapping("/readers/{id}")
	public Reader updateReader(@PathVariable Long id, @RequestBody Reader readerDetails) {
		Reader reader = readerRepository.findById(id).orElseThrow();
		reader.setName(readerDetails.getName());
		reader.setEmail(readerDetails.getEmail());
		return readerRepository.save(reader);
	}

	@DeleteMapping("/readers/{id}")
	public String deleteReader(@PathVariable Long id) {
		readerRepository.deleteById(id);
		return "Deleted Successfully";
	}



	// Book endpoint
	@PostMapping("/books")
	public Book addBook(@RequestBody Book book) {
		return bookRepository.save(book);
	}

	@GetMapping("/books")
	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	@PutMapping("/books/{id}")
	public Book updateBook(@PathVariable Long id, @RequestBody Book bookDetails) {
		Book book = bookRepository.findById(id).orElseThrow();
		book.setTitle(bookDetails.getTitle());
		book.setPublishDate(bookDetails.getPublishDate());
		book.setReader(bookDetails.getReader());
		book.setCategory(bookDetails.getCategory());
		book.setAuthor(bookDetails.getAuthor());
		return bookRepository.save(book);
	}

	@DeleteMapping("/books/{id}")
	public String deleteBook(@PathVariable Long id) {
		bookRepository.deleteById(id);
		return "Deleted Successfully";
	}




	// Author endpoints
	@PostMapping("/authors")
	public Author addAuthor(@RequestBody Author author) {
		return authorRepository.save(author);
	}

	@GetMapping("/authors")
	public List<Author> getAllAuthors() {
		return authorRepository.findAll();
	}

	@PutMapping("/authors/{id}")
	public Author updateAuthor(@PathVariable Long id, @RequestBody Author authorDetails) {
		Author author = authorRepository.findById(id).orElseThrow();
		author.setName(authorDetails.getName());
		return authorRepository.save(author);
	}

	@DeleteMapping("/authors/{id}")
	public String deleteAuthor(@PathVariable Long id) {
		authorRepository.deleteById(id);
		return "Deleted Successfully";
	}




	// Category endpoints
	@PostMapping("/categories")
	public Category addCategory(@RequestBody Category category) {
		return categoryRepository.save(category);
	}

	@GetMapping("/categories")
	public List<Category> getAllCategories() {
		return categoryRepository.findAll();
	}

	@PutMapping("/categories/{id}")
	public Category updateCategory(@PathVariable Long id, @RequestBody Category categoryDetails) {
		Category category = categoryRepository.findById(id).orElseThrow();
		category.setName(categoryDetails.getName());
		return categoryRepository.save(category);
	}

	@DeleteMapping("/categories/{id}")
	public String deleteCategory(@PathVariable Long id) {
		categoryRepository.deleteById(id);
		return "Deleted Successfully";
	}
}
