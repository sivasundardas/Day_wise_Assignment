package com.example.library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment2Day12LibraryManagementSystemJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
