package com.example.ecommerce;

public class Product {
    public void addProduct() {
        System.out.println("Product added to catalog.");
    }

    public void listProducts() {
        System.out.println("Listing all available products.");
    }
}
